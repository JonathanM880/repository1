package inicialite;

import com.DbConfig;
import modelo.Producto;
import servicios.ServicioP;
import servicios.ServicioProducto;

public class main {
	public static void main(String[] args) {
		System.out.println("aaa");
		DbConfig conf = new DbConfig();
		ServicioProducto serv = new ServicioP();
		serv.setDbConfig(conf);
		var prod = new Producto(1,"agua", 2.4, 100);
		serv.create(prod);
	}
}
