package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.DbConfig;

import modelo.Producto;

public class ServicioP implements ServicioProducto {

	DbConfig dbConfig = new DbConfig();

	@Override
	public void setDbConfig(DbConfig dbConfig) {
		// TODO Auto-generated method stub

	}

	@Override
	public void create(Producto p) {
		// TODO Auto-generated method stub
		try (Connection con = (Connection) dbConfig.getConnection()) {
			var pstmt = con.prepareStatement("INSERT INTO Producto (name, precio, cantidad) VALUES (?, ?, ?)");
			pstmt.setString(1, p.getNombre());
			pstmt.setDouble(2, p.getPrecio());
			pstmt.setInt(3, p.getCantidad());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

		}
	}

	@Override
	public Producto read(int id) {
		Producto producto = null;
		try (var con = dbConfig.getConnection()) {
			var pstmt = con.prepareStatement("SELECT * FROM producto WHERE id = ?");
			pstmt.setInt(1, id);
			var rs = pstmt.executeQuery();
			if (rs.next()) {
				producto = new Producto(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio"),
						rs.getInt("cantidad"));
			}
		} catch (SQLException e) {
			System.out.println("Error al leer producto: " + e.getMessage());
		}
		return producto;
	}

	@Override
	public List<Producto> listar() {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public void upgrade(Producto p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub

	}

}
