package servicios;

import com.DbConfig;
import modelo.Producto;
import java.util.List;

public interface ServicioProducto {
	void setDbConfig(DbConfig dbConfig);

	void create(Producto p);

	Producto read(int id);

	List<Producto> listar();

	void upgrade(Producto p);

	void delete(int id);
}
