package com;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.hibernate.HikariConnectionProvider;

import java.sql.Connection;
import java.sql.SQLException;

public class DbConfig implements AutoCloseable {
    private HikariDataSource ds;

    public DbConfig() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlite:db.db");
        config.setUsername("root");
        config.setPassword("root"); 
        config.setConnectionTimeout(3000);
        ds = new HikariDataSource(config);
        System.out.println("DataSource configurado correctamente.");
    }

    public Connection getConnection() {
        try {
            System.out.println("Conexión exitosa...");
            return ds.getConnection();
        } catch (SQLException e) {
            System.err.println("Error al obtener la conexión: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public static HikariConnectionProvider get() {
        
        return null;
    }

    @Override
    public void close() {
        if (ds != null) {
            ds.close();
            System.out.println("DataSource cerrado correctamente.");
        }
    }
}
