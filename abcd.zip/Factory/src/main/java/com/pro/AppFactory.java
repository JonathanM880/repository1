package com.pro;

import com.abs.Factory;
import com.abs.FactoryImpl;
import com.model.Computadora;

public class AppFactory {
	public static void main(String[] args) {
		Factory fac = new FactoryImpl();
		Computadora pc = fac.create("pc");
		Computadora laptop = fac.create("laptop");
		Computadora server = fac.create("server");
	}
}
