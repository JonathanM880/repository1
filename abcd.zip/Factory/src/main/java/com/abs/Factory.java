package com.abs;

import com.model.Computadora;

public interface Factory {

	<T> T create(String name);
}
