package com.model;

import com.anotaciones.MiComponente;

@MiComponente(name = "Laptop")
public class Laptop extends Computadora{
	{
		System.out.println("se creó una instancia de laptop");
	}
}
