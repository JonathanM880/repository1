package com.inter;

import com.model.Computadora;

public interface Factory {
	void init(String pkgName);
	<T> T create(String name);
}
