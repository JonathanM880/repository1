package com.model;

import com.anotaciones.MiComponente;

@MiComponente(name = "server")
public class Server extends Computadora {
	{
		System.out.println("se creó una instancia de server");
	}
}
