package com.progavanzada.primitivasinicio2025;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

//clase de la primitiva
// Opengl trabaja con identificadores (ids)
public class Point {
    private final FloatBuffer vertexBuffer; //buffer de memoria que guarda coordenadas de vertices
    private final int mProgram; //combinar vertex shader con fragment shader
    private int positionHandle; //pasarle los datos de posición del vértice al shader.
    private int colorHandle; //almacena id del color
    static final int COORDS_POR_VERTEX = 3; //El número de coordenadas por vértice (x, y, z).
    static float pointCoord[] = {0.0f,0.0f,0.0f}; //coordenadas del punto (entre -1 y 1)
    private final int vertexCount = pointCoord.length/COORDS_POR_VERTEX; //cuenta vertices que vamos a dibujar (el punto tiene un vertice)
    private final int vertexStride = COORDS_POR_VERTEX*4; //determinar el tamaño de memoria de cada vertice || el programa sabe que cada 12 bytes tenemos un vertice
    // siempre debe dar 12
    float color[] = {1.0f,0.0f,0.0f,1.0f}; //color del punto || se puede hacer de otra forma

    public Point(){
        // siempre necesarias
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(pointCoord.length*4);
        byteBuffer.order(ByteOrder.nativeOrder()); //sirve para establecer el orden de bytes (endianness) del buffer
        vertexBuffer = byteBuffer.asFloatBuffer(); //convierte a floatBuffer para trabajar con floats en lugar de bytes
        vertexBuffer.put(pointCoord); //Copia los valores del arreglo pointCoord al FloatBuffer
        vertexBuffer.position(0); //para que empiece desde la posicion 0 del arreglo
    }

    private final String vertexShaderCode =
            "attribute vec4 vPosition;"+
            "void main(){"+;
            //es como una variable vec4 es como un tipo de dato y vPosition siempre debe llamarse asi
    private final String fragmentShaderCode= "";

}