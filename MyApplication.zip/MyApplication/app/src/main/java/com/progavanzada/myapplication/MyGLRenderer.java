package com.progavanzada.myapplication;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

//cuando y como
public class MyGLRenderer implements GLSurfaceView.Renderer { //definir que es lo que se dibuja y cuando se dibuja

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) { //metodo que se llama una sola vez cuando se crea el contexto de opengl
                            //f para inficarle que es decimal
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //color del fondo || estructura de colo  RGB (graficos) CMYK(impresion) EXADECIMAL(web)
        //GLES20.- version opengl 2.0 || RGBA RED, GREEN, BLUE, ALPHA(transparencia 0 muy transparente, 1 nada transparente)  (entre 0(nada) y 1(todoo))

    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) { //ajustar tamaño pantalla
        GLES20. glViewport(0,0,width,height);
        //desde donde empiece || ancho alto
    }

    @Override
    public void onDrawFrame(GL10 gl) { // se especifica lo que se va a dibujar --frame imagen escenografia

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); //limpia el color del buffer, el color del fondo definido, lienzo limpio (obligatoria)

    }
}
