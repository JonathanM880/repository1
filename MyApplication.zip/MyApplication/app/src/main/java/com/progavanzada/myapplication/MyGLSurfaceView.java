package com.progavanzada.myapplication;

import android.content.Context;
import android.opengl.GLSurfaceView;
//dibujar
public class MyGLSurfaceView extends GLSurfaceView { //mostrar imagenes opengl
    private final MyGLRenderer renderer;

    public MyGLSurfaceView(Context context) {
        super(context);

        //version de OpenGL
        setEGLContextClientVersion(2);
        renderer = new MyGLRenderer();
        setRenderer(renderer); //manejar lo que se dibuja en la pantalla, especifico lo que se va a dibujar
    }

}
